<?php $__env->startSection('title', 'Tax Mail - Income Tax'); ?>
<style>
    * {
      box-sizing: border-box;
    }
    .zoom {
      transition: transform .2s;
      width: 40px;
      height: 40px;
      margin: 0 auto;
    }

    .zoom:hover {
      -ms-transform: scale(1.5); /* IE 9 */
      -webkit-transform: scale(1.5); /* Safari 3-8 */
      transform: scale(10);
      margin-bottom: 40px;
    }
    </style>
<?php $__env->startSection('content'); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="content-header row pt-3">
                        <div class="content-header-left col-md-6 col-12">
                            <h4 class="card-title">Update Income Tax Data </h4>
                        </div>
                        <div class="content-header-right col-md-6 col-12">
                            <div class="btn-group" style="float: right!important;" role="group"
                                aria-label="Button group with nested dropdown">
                                <div class="btn-group mb-1" role="group">
                                    <a href="<?php echo e(url('/admin/users')); ?>"
                                        class="btn btn-outline-primary dropdown-menu-right"><i
                                            class="feather uil-arrow-left icon-left"></i>Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <form method="POST" id="userform" action="<?php echo e(url('admin/update-documents/income-tax-data/'.$incometaxdata['id'])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Assessment Year</label>
                            <input type="text" class="form-control" value="<?php echo e($incometaxdata['assessment_year']); ?>" name="assessment_year"  placeholder="Enter Assessment Year">
                            <?php $__errorArgs = ['assessment_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="assessment_year-error" class="error" for="assessment_year"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label class="form-label">Filing Type</label>
                            <select class="form-control" name="filing_type" id="filing_type">
                                <option selected disabled style="display:none;">Select Filing Type</option>
                                <option <?php if($incometaxdata['filing_type']=='Original'): ?>
                                    selected
                                <?php endif; ?> value="Original">Original</option>
                                <option value="" disabled>Other</option>
                            </select>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">ITR</label>
                            <select class="form-control" name="itr" id="itr">
                                <option selected disabled>Select ITR</option>
                                <option <?php if($incometaxdata['itr']=='ITR-1'): ?>
                                selected
                            <?php endif; ?> value="ITR-1" >ITR-1</option>
                                <option  <?php if($incometaxdata['itr']=='ITR-2'): ?>
                                selected
                            <?php endif; ?> value="ITR-2" >ITR-2</option>
                                <option <?php if($incometaxdata['itr']=='ITR-3'): ?>
                                selected
                            <?php endif; ?> value="ITR-3" >ITR-3</option>
                                <option <?php if($incometaxdata['itr']=='ITR-4'): ?>
                                selected
                            <?php endif; ?> value="ITR-4" >ITR-4</option>
                                <option <?php if($incometaxdata['itr']=='ITR-5'): ?>
                                selected
                            <?php endif; ?> value="ITR-5" >ITR-5</option>
                                <option <?php if($incometaxdata['itr']=='ITR-6'): ?>
                                selected
                            <?php endif; ?> value="ITR-6" >ITR-6</option>
                                <option <?php if($incometaxdata['itr']=='ITR-7'): ?>
                                selected
                            <?php endif; ?> value="ITR-7" >ITR-7</option>
                            </select>
                            <?php $__errorArgs = ['itr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="email-error" class="error" for="email"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Acknowledgment No.</label>
                            <input type="text" class="form-control" value="<?php echo e($incometaxdata['acknowledgment_no']); ?>" name="acknowledgment_no">
                            <?php $__errorArgs = ['acknowledgment_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="acknowledgment_no-error" class="error" for="acknowledgment_no"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Filing Date</label>
                            <input type="date" class="form-control" value="<?php echo e($incometaxdata['filing_date']); ?>" name="filing_date">
                            <?php $__errorArgs = ['filing_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="filing_date-error" class="error" for="filing_date"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Total Income</label>
                            <input type="number" class="form-control" value="<?php echo e($incometaxdata['total_income']); ?>" name="total_income">
                            <?php $__errorArgs = ['mode_of_filing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="total_income-error" class="error" for="total_income"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Type</label>
                            <select class="form-control" name="type" id="type">
                                <option selected disabled>Select Type</option>
                                <option value="ITR Achnowledgement">ITR Achnowledgement</option>
                                <option value="Computation">Computation</option>
                                <option value="ITR Form">ITR Form</option>
                                <option value="Challan">Challan</option>
                                <option value="Form 26AS">Form 26AS</option>
                                <option value="AIS/TIS">AIS/TIS</option>
                                <option value="MISC Documents">MISC Documents</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="type-error" class="error" for="type"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6" >
                            <label class="form-label">Upload Documents</label>
                            <input class="form-control" id="documents" accept=".png, .jpg, .jpeg, .pdf, .docx, .doc" name="documents[]" multiple type="file" >
                        </div>
                    </div>
                    <div class="row">
                        <?php if(isset($incometaxdocuments)): ?>
                        <label class="form-label"><strong>Uploded Documents </strong></label><br>
                        <label class="form-label">ITR Achnowledgement Documents</label>
                        <?php $__currentLoopData = $incometaxdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='ITR Achnowledgement'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/income-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/IncomeTax/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Computation Documents</label>
                        <?php $__currentLoopData = $incometaxdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Computation'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/income-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/IncomeTax/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Challan Documents</label>
                        <?php $__currentLoopData = $incometaxdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Challan'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/income-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/IncomeTax/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">ITR Form Documents</label>
                        <?php $__currentLoopData = $incometaxdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='ITR Form'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/income-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/IncomeTax/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Form 26AS Documents</label>
                        <?php $__currentLoopData = $incometaxdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Form 26AS'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/income-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/IncomeTax/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">AIS/TIS Documents</label>
                        <?php $__currentLoopData = $incometaxdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='AIS/TIS'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/income-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/IncomeTax/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">MISC Documents</label>
                        <?php $__currentLoopData = $incometaxdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='MISC Documents'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/income-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/IncomeTax/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/admin/incometax.blade.php ENDPATH**/ ?>