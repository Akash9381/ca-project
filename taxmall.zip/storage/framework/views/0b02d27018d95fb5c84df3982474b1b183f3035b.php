<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>How to Integrate Razorpay Payment Gateway in Laravel 9 - LaravelTuts.com</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <div id="app">
        <main class="py-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 offset-3 col-md-offset-6">

                        <?php if($message = Session::get('error')): ?>
                            <div class="error alert alert-danger alert-dismissible fade in" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true" id="err">×</span>
                                </button>
                                <strong>Error!</strong> <?php echo e($message); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($message = Session::get('success')): ?>
                            <div class="success alert alert-success alert-dismissible fade <?php echo e(Session::has('success') ? 'show' : 'in'); ?>" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true" id="succ">×</span>
                                </button>
                                <strong>Success!</strong> <?php echo e($message); ?>

                            </div>
                        <?php endif; ?>

                        <div class="card card-default">
                            <div class="card-header">
                                <h6>Please Pay, only 100 Rs for Dashboard Access. It is valid for 3 days.</h6>
                            </div>

                            <div class="card-body text-center">
                                <form action="<?php echo e(route('razorpay.payment.store')); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <script src="https://checkout.razorpay.com/v1/checkout.js"
                                            data-key="<?php echo e(env('RAZORPAY_KEY')); ?>"
                                            data-amount="10000"
                                            data-buttontext="Pay 100 INR"
                                            data-name="TaxMail.com"
                                            data-description="Rozerpay"
                                            data-image="https://laraveltuts.com/wp-content/uploads/2022/08/laraveltuts-rounde-logo.png"
                                            data-prefill.name="Tax Mail"
                                            data-prefill.email="email"
                                            data-theme.color="#ff7529">
                                    </script>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>
        $(document).ready(function(){
            $("#succ").click(function(){
                $(".success").hide();
            });
            $("#err").click(function(){
                $(".error").hide();
            });
        });
    </script>
</body>
</html>
<?php /**PATH G:\Akash\git project\tax-mail\resources\views/frontend/login/razorpay.blade.php ENDPATH**/ ?>