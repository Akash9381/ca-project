<?php $__env->startSection('title', 'Tax Mail - Tax Audit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="content-header row pt-3">
                        <div class="content-header-left col-md-6 col-12">
                            <h4 class="card-title">Update Tax Audit Data </h4>
                        </div>
                        <div class="content-header-right col-md-6 col-12">
                            <div class="btn-group" style="float: right!important;" role="group"
                                aria-label="Button group with nested dropdown">
                                <div class="btn-group mb-1" role="group">
                                    <a href="<?php echo e(url('/admin/users')); ?>"
                                        class="btn btn-outline-primary dropdown-menu-right"><i
                                            class="feather uil-arrow-left icon-left"></i>Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <form method="POST" id="userform" action="<?php echo e(url('admin/update-documents/tax-audit-data/'.$taxauditdata['id'])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Pan No.</label>
                            <input type="text" class="form-control"  value="<?php echo e($taxauditdata['pan_card']); ?>" name="pan_card"  placeholder="Enter Pan No.">
                            <?php $__errorArgs = ['pan_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label id="pan_card-error" class="error" for="pan_card"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label class="form-label">Acknowledgment No.</label>
                            <input type="number" class="form-control" value="<?php echo e($taxauditdata['acknowledgment_no']); ?>" name="acknowledgment_no">
                            <?php $__errorArgs = ['acknowledgment_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="acknowledgment_no-error" class="error" for="acknowledgment_no"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Filing Date</label>
                            <input type="date" class="form-control" name="filing_date" value="<?php echo e($taxauditdata['filing_date']); ?>"  placeholder="Enter Filing Date">
                            <?php $__errorArgs = ['filing_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label id="filing_date-error" class="error" for="filing_date"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Assessment Year</label>
                            <input type="text" class="form-control" style="text-transform: capitalize" name="assessment_year" value="<?php echo e($taxauditdata['assessment_year']); ?>"  placeholder="Enter Assessment Year">
                            <?php $__errorArgs = ['assessment_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="assessment_year-error" class="error" for="assessment_year"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Filing Type</label>
                            <select class="form-control" name="filing_type" id="filing_type">
                                <option selected style="display:none;">Select Filing Type</option>
                                <option <?php if($taxauditdata['filing_type']=='Original'): ?>
                                    selected
                                <?php endif; ?> value="Original">Original</option>
                                <option <?php if($taxauditdata['filing_type']=='Revised'): ?>
                                    selected
                                <?php endif; ?> value="Revised">Revised</option>
                            </select>
                            <?php $__errorArgs = ['filing_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="filing_type-error" class="error" for="filing_type"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Status</label>
                            <select class="form-control" name="status" >
                            <option selected style="display:none;">Select Status</option>
                                <option <?php if($taxauditdata['status']=='Form verified'): ?>
                                    selected
                                <?php endif; ?> value="Form verified">Form verified</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="form_no-error" class="error" for="form_no"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Filed By</label>
                            <select class="form-control" name="filed_by" id="filed_by">
                                <option selected style="display:none;">Select Status</option>
                                    <option <?php if($taxauditdata['filed_by']=='SELF'): ?>
                                        selected
                                    <?php endif; ?> value="SELF">SELF</option>
                                    <option <?php if($taxauditdata['filed_by']=='REP'): ?>
                                        selected
                                    <?php endif; ?> value="REP">REP</option>
                                </select>
                            <?php $__errorArgs = ['filed_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="filed_by-error" class="error" for="filed_by"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Type</label>
                            <select class="form-control" name="type" id="type">
                                <option selected disabled>Select Type</option>
                                <option value="Achnowledgement">Achnowledgement</option>
                                <option value="Form">Form</option>
                                <option value="Final Statement">Final Statement</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="type-error" class="error" for="type"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label class="form-label">Upload Documents</label>
                            <input class="form-control" id="documents" accept=".png, .jpg, .jpeg, .pdf, .docx, .doc" name="documents[]" multiple type="file" >
                        </div>
                    </div>
                    <div class="row">
                        <?php if(isset($taxauditdocuments)): ?>
                        <label class="form-label"><strong>Uploded Documents </strong></label><br>
                        <label class="form-label">Achnowledgement Documents</label>
                        <?php $__currentLoopData = $taxauditdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Achnowledgement'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/tax-audit-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TaxAudit/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Form Documents</label>
                        <?php $__currentLoopData = $taxauditdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Form'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/tax-audit-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TaxAudit/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Final Statement Documents</label>
                        <?php $__currentLoopData = $taxauditdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Final Statement'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/tax-audit-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TaxAudit/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $("#tax_type").on('change', function(){
        $('.excel').show();
    });
    // $("#userform").submit(function(){
    //     if($("#tax_type").val()==null){
    //         alert("null");
    //     }else{
    //         alert("value");
    //     }
    // })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/admin/taxaudit.blade.php ENDPATH**/ ?>