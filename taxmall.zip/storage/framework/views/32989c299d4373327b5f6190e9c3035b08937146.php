<?php $__env->startSection('content'); ?>
    <div class="main-panel" id="main-panel">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
            <div class="row text-light">
                <div class="col-12">
                    GST ARN: <b><?php echo e($gstdata['arn']); ?></b>
                </div>
                <div class="col-12 mt-1">
                  Return Type: <b><?php echo e($gstdata['return_type']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Financial Year: <b><?php echo e($gstdata['financial_year']); ?></b>
                </div>
                <div class="col-12 mt-1">
                   Tax Period: <b><?php echo e($gstdata['tax_period']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Filing Date: <b><?php echo e($gstdata['filing_date']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Status: <b><?php echo e($gstdata['status']); ?></b>
                </div>
                <div class="col-12 my-1">
                    Mode Of Filing: <b><?php echo e($gstdata['mode_of_filing']); ?></b>
                </div>
                <label for=""></label>
            </div>
            <div class="container-fluid">
                <div class="navbar-wrapper">
                    <div class="navbar-toggle">
                        <button type="button" class="navbar-toggler">
                            <span class="navbar-toggler-bar bar1"></span>
                            <span class="navbar-toggler-bar bar2"></span>
                            <span class="navbar-toggler-bar bar3"></span>
                        </button>
                    </div>
                    

                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                    aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navigation">

                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <p>
                                <span class="d-lg-none d-md-block">Status</span>
                            </p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="panel-header panel-header-lg">

            
        </div>
        <div class="content">
            
        <?php if(isset($gstdocuments)): ?>
        <div class="row text-center mt-5">
            <div class="col-12">
                <h3 for=""><u>Achnowledgement</u></h3>
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $gstdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row"  >
                <?php if($item['type']=='Achnowledgement'): ?>
                <div class="mb-3 col-md-6 col-12 text-center">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/GST/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="row text-center">
            <div class="col-12">
                <h4 for=""><u>No Documents of Achnowledgement</u></h4>
            </div>
        </div>
    </label>
        <?php endif; ?>
        <hr>
        <div class="row text-center">
            <div class="col-12">
                <h3 for=""><u>Form</u></h3>
            </div>
        </div>
        <?php $__currentLoopData = $gstdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row" >
                <?php if($item['type']=='Form'): ?>
                <div class="mb-3 col-md-6 col-12 text-center form_data" >
                    <iframe  width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/GST/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="row text-center">
            <div class="col-12">
                <h3 for=""><u>Challan</u></h3>
            </div>
        </div>
        <?php $__currentLoopData = $gstdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <?php if($item['type']=='Challan'): ?>
                <div class="mb-3 col-md-6 col-12 text-center">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/GST/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('.achnowledgement').click(function(){
            $("#Achnowledgement").show();
            $("#Form").hide();
            $("#Challan").hide();
            $(".achnowledgement").css('color','#fff');
            $(".achnowledgement").css('background','green');
            $(".form").css('color','black');
            $(".form").css('background','#fff');
            $(".challan").css('color','black');
            $(".challan").css('background','#fff');
        });
        $('.form').click(function(){
            $("#Achnowledgement").hide();
            $("#Form").show();
            $("#Challan").hide();
            $(".achnowledgement").css('color','black');
            $(".achnowledgement").css('background','#fff');
            $(".form").css('color','#fff');
            $(".form").css('background','green');
            $(".challan").css('color','black');
            $(".challan").css('background','#fff');
        });
        $('.challan').click(function(){
            $("#Achnowledgement").hide();
            $("#Form").hide();
            $("#Challan").show();
            $(".achnowledgement").css('color','black');
            $(".achnowledgement").css('background','#fff');
            $(".form").css('color','black');
            $(".form").css('background','#fff');
            $(".challan").css('color','#fff');
            $(".challan").css('background','green');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard_layouts.dashboard_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/frontend/login/gstdata.blade.php ENDPATH**/ ?>