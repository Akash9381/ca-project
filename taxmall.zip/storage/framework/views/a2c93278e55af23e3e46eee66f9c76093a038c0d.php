<?php $__env->startSection('content'); ?>
    <div class="main-panel" id="main-panel">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
            <div class="row text-light">
                <div class="col-12">
                    PAN No.: <b><?php echo e($taxauditdata['pan_card']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Acknowledgment No.: <b><?php echo e($taxauditdata['acknowledgment_no']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Assessment Year: <b><?php echo e($taxauditdata['assessment_year']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Filing Date: <b><?php echo e($taxauditdata['filing_date']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Filed By: <b><?php echo e($taxauditdata['filed_by']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Filing Type: <b><?php echo e($taxauditdata['filing_type']); ?></b>
                </div>
                <div class="col-12 mt-1">
                    Status: <b><?php echo e($taxauditdata['status']); ?></b>
                </div>
                <label for=""></label>
            </div>
            <div class="container-fluid">
                <div class="navbar-wrapper">
                    <div class="navbar-toggle">
                        <button type="button" class="navbar-toggler">
                            <span class="navbar-toggler-bar bar1"></span>
                            <span class="navbar-toggler-bar bar2"></span>
                            <span class="navbar-toggler-bar bar3"></span>
                        </button>
                    </div>
                    

                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                    aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navigation">

                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <p>
                                <span class="d-lg-none d-md-block">Status</span>
                            </p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="panel-header panel-header-lg">

            
        </div>
        <div class="content">
        <?php if(isset($taxauditdocuments)): ?>
        <div class="row text-center mt-5">
            <div class="col-12">
                <h3 for=""><u>Achnowledgement</u></h3>
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $taxauditdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row"  >
                <?php if($item['type']=='Achnowledgement'): ?>
                <div class="mb-3 col-md-6 col-12 text-center">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TaxAudit/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="row text-center">
            <div class="col-12">
                <h4 for=""><u>No Documents of Achnowledgement</u></h4>
            </div>
        </div>
    </label>
        <?php endif; ?>
        <hr>
        <div class="row text-center">
            <div class="col-12">
                <h3 for=""><u>Form</u></h3>
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $taxauditdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row" >
                <?php if($item['type']=='Form'): ?>
                <div class="mb-3 col-md-6 col-12 text-center form_data" >
                    <iframe  width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TaxAudit/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="row text-center">
                <div class="col-12">
                    <h4 for=""><u>No Documents of Form</u></h4>
                </div>
            </div>
        <?php endif; ?>
        <hr>
        <div class="row text-center">
            <div class="col-12">
                <h3 for=""><u>Final Statement</u></h3>
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $taxauditdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row">
                <?php if($item['type']=='Final Statement'): ?>
                <div class="mb-3 col-md-6 col-12 text-center">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TaxAudit/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="row text-center">
            <div class="col-12">
                <h4 for=""><u>No Documents of Final Statement</u></h4>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard_layouts.dashboard_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/frontend/login/taxauditdata.blade.php ENDPATH**/ ?>