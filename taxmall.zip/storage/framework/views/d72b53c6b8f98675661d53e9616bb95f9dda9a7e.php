<!doctype html>
<html lang="zxx">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/animate.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/owl.carousel.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/fontawesome.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/odometer.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/magnific-popup.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/slick.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/dark.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('frontend/assets/img/favicon.png')); ?>">
</head>

<body data-bs-spy="scroll" data-bs-offset="120">

    <div class="preloader">
        <div class="preloader">
            <span></span>
            <span></span>
        </div>
    </div>
<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>


<div class="go-top">
    <i class="fa fa-chevron-up"></i>
    <i class="fa fa-chevron-up"></i>
</div>

<script src="<?php echo e(asset('frontend/assets/js/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/owl.carousel.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/jquery.appear.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/odometer.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/slick.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/particles.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/jquery.ripples-min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/wow.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/jquery.ajaxchimp.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/form-validator.min.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/contact-form-script.js')); ?>"></script>

<script src="<?php echo e(asset('frontend/assets/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH G:\Akash\git project\tax-mail\resources\views/frontend/layouts/frontend_layouts.blade.php ENDPATH**/ ?>