<?php $__env->startSection('content'); ?>
    <div class="main-panel" id="main-panel">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
            <div class="row text-light">
                <div class="col-12">
                    GST ARN: <b><?php echo e($arndata['arn']); ?></b>
                </div>
                <div class="col-12 mt-2">
                  Return Type: <b><?php echo e($arndata['return_type']); ?></b>
                </div>
                <div class="col-12 mt-2">
                    Financial Year: <b><?php echo e($arndata['financial_year']); ?></b>
                </div>
                <div class="col-12 mt-2">
                   Tax Period: <b><?php echo e($arndata['tax_period']); ?></b>
                </div>
                <div class="col-12 mt-2">
                    Filing Date: <b><?php echo e($arndata['filing_date']); ?></b>
                </div>
                <div class="col-12 mt-2">
                    Status: <b><?php echo e($arndata['status']); ?></b>
                </div>
                <div class="col-12 my-2">
                    Mode Of Filing: <b><?php echo e($arndata['mode_of_filing']); ?></b>
                </div>
                <label for=""></label>
            </div>
            <div class="container-fluid">
                <div class="navbar-wrapper">
                    <div class="navbar-toggle">
                        <button type="button" class="navbar-toggler">
                            <span class="navbar-toggler-bar bar1"></span>
                            <span class="navbar-toggler-bar bar2"></span>
                            <span class="navbar-toggler-bar bar3"></span>
                        </button>
                    </div>
                    

                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                    aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navigation">

                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <p>
                                <span class="d-lg-none d-md-block">Status</span>
                            </p>
                            </a>
                        </li>


                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="panel-header panel-header-lg">

            
        </div>
        <div class="row">

        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard_layouts.dashboard_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/frontend/login/downloaddata.blade.php ENDPATH**/ ?>