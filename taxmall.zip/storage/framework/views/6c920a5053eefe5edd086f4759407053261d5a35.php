    
    <?php $__env->startSection('title', 'Dashboard - Tax Mail'); ?>
    <?php $__env->startSection('content'); ?>
        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="content-header row pt-3">
                            <div class="content-header-left col-md-6 col-12">
                                <h4 class="card-title">Update User</h4>
                            </div>
                            <div class="content-header-right col-md-6 col-12">
                                <div class="btn-group" style="float: right!important;" role="group"
                                    aria-label="Button group with nested dropdown">
                                    <div class="btn-group mb-1" role="group">
                                        <a href="<?php echo e(url('/admin/users')); ?>"
                                            class="btn btn-outline-primary dropdown-menu-right"><i
                                                class="feather uil-arrow-left icon-left"></i> Back</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form action="<?php echo e(url('admin/update-user/'.$user['id'])); ?>" id="userform" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="mb-3 col-12 col-md-6">
                                <label  class="form-label">Name</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e($user['name']); ?>"  placeholder="Enter Name">
                            </div>
                            <div class="mb-3 col-12 col-md-6">
                                <label  class="form-label">Email address</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e($user['email']); ?>"  placeholder="Enter email">
                            </div>
                            <div class="mb-3 col-12 col-md-6">
                                <label  class="form-label">Mobile</label>
                                <input type="number" class="form-control" name="number" value="<?php echo e($user['number']); ?>" placeholder="Enter Mobile Number">
                            </div>
                            <div class="mb-3 col-12 col-md-6">
                                <label  class="form-label">PAN No.</label>
                                <input type="text" class="form-control" name="pan_card" value="<?php echo e($user['pan_card']); ?>" placeholder="Enter PAN No.">
                            </div>
                            <div class="mb-3 col-12 col-md-6">
                                <label  class="form-label">City</label>
                                <input type="text" class="form-control" name="city" value="<?php echo e($user['city']); ?>"   placeholder="Enter City">
                            </div>
                            <div class="mb-3 col-12 col-md-6 excel">
                                <label class="form-label">Tax Type</label>
                                <select class="form-control" name="tax_type" id="tax_type">
                                    <option selected disabled>Select Tax Type</option>
                                    <option value="income_tax">Income Tax</option>
                                    <option value="gst">GST</option>
                                    <option value="tds">TDS</option>
                                    <option value="tax_audit">Tax Audit</option>
                                </select>
                            </div>
                            <div class="mb-3 col-12 col-md-6 excel" style="display: none">
                                <label class="form-label">Excel File Upload Here</label>
                                <input class="form-control" type="file" accept=".xlsx" name="file" >
                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                    <hr>
                    <?php if($income_tax_data->count()>0): ?>
                    <div class="row">
                        <div class="content-header row pt-3">
                            <div class="content-header-left col-md-6 col-12">
                                <h4 class="card-title">Showing <?php echo e($income_tax_data->count()); ?> of <?php echo e($income_tax_data->total()); ?> User Income Tax Data </h4>
                            </div>
                            <div class="content-header-right col-md-6 col-12">
                                
                                
                            </div>
                        </div>
                        <div class="col-12">
                            <table class="table table-striped table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>Assessment Year</th>
                                        <th>Filing Type</th>
                                        <th>ITR</th>
                                        <th>Acknowledgment No.</th>
                                        <th>Filing Date</th>
                                        <th>Total Income</th>
                                        <th>Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $income_tax_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <?php echo e($data['assessment_year']); ?>

                                        </td>
                                        <td><?php echo e($data['filing_type']); ?></td>
                                        <td><?php echo e($data['itr']); ?></td>
                                        <td><?php echo e($data['acknowledgment_no']); ?></td>
                                        <td><?php echo e($data['filing_date']); ?></td>
                                        <td><?php echo e($data['total_income']); ?></td>
                                        <td class="table-action">
                                            <a href="<?php echo e(url('/admin/upload-documents/income-tax/'.$data['id'])); ?>" class="action-icon"><i
                                                class="mdi mdi-pencil"></i></a>
                                                <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/delete-income-tax/'.$data['id'])); ?>" class="action-icon"> <i
                                                    class="mdi mdi-delete"></i></a>
                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="text-center">
                                        <th colspan="5">
                                            No records found
                                        </th>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            <?php echo e($income_tax_data->links()); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($gst_data->count()>0): ?>
                    <hr>
                    <div class="row">
                        <div class="content-header row pt-3">
                            <div class="content-header-left col-md-6 col-12">
                                <h4 class="card-title">Showing <?php echo e($gst_data->count()); ?> of <?php echo e($gst_data->total()); ?> User GST Data </h4>
                            </div>
                            <div class="content-header-right col-md-6 col-12">
                                
                                
                            </div>
                        </div>

                        <div class="col-12">
                            <table class="table table-striped table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>ARN</th>
                                        <th>Return Type</th>
                                        <th>Financial Year</th>
                                        <th>Tax Period</th>
                                        <th>Filing Date</th>
                                        <th>Status</th>
                                        <th>Mode of Filing</th>
                                        <th>Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $gst_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($data['arn']); ?></td>
                                        <td><?php echo e($data['return_type']); ?></td>
                                        <td><?php echo e($data['financial_year']); ?></td>
                                        <td><?php echo e($data['tax_period']); ?></td>
                                        <td><?php echo e($data['filing_date']); ?></td>
                                        <td><?php echo e($data['status']); ?></td>
                                        <td><?php echo e($data['mode_of_filing']); ?></td>
                                        <td class="table-action">
                                            <a href="<?php echo e(url('/admin/upload-documents/gst-data/'.$data['id'])); ?>" class="action-icon"><i
                                                class="mdi mdi-pencil"></i></a>
                                                <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/delete-gst/'.$data['id'])); ?>" class="action-icon"> <i
                                                    class="mdi mdi-delete"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="text-center">
                                        <th colspan="5">
                                            No records found
                                        </th>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            <?php echo e($gst_data->links()); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($tax_audit->count()>0): ?>
                    <hr>
                    <div class="row">
                        <div class="content-header row pt-3">
                            <div class="content-header-left col-md-6 col-12">
                                <h4 class="card-title">Showing <?php echo e($tax_audit->count()); ?> of <?php echo e($tax_audit->total()); ?> User Tax Audit Data </h4>
                            </div>
                            <div class="content-header-right col-md-6 col-12">
                                
                                
                            </div>
                        </div>

                        <div class="col-12">
                            <table class="table table-striped table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>PAN Card</th>
                                        <th>Acknowledgment No.</th>
                                        <th>Assessment Year</th>
                                        <th>Filing Date</th>
                                        <th>Filing By</th>
                                        <th>Filing Type</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $tax_audit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($data['pan_card']); ?></td>
                                        <td><?php echo e($data['acknowledgment_no']); ?></td>
                                        <td><?php echo e($data['assessment_year']); ?></td>
                                        <td><?php echo e($data['filing_date']); ?></td>
                                        <td><?php echo e($data['filed_by']); ?></td>
                                        <td><?php echo e($data['filing_type']); ?></td>
                                        <td><?php echo e($data['status']); ?></td>
                                        <td class="table-action">
                                            <a href="<?php echo e(url('/admin/upload-documents/tax-audit-data/'.$data['id'])); ?>" class="action-icon"><i
                                                class="mdi mdi-pencil"></i></a>
                                                <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/delete-tax-audit/'.$data['id'])); ?>" class="action-icon"> <i
                                                    class="mdi mdi-delete"></i></a>
                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="text-center">
                                        <th colspan="8">
                                            No records found
                                        </th>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            <?php echo e($gst_data->links()); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($tds_data->count()>0): ?>
                    <hr>
                    <div class="row">
                        <div class="content-header row pt-3">
                            <div class="content-header-left col-md-6 col-12">
                                <h4 class="card-title">Showing <?php echo e($tds_data->count()); ?> of <?php echo e($tds_data->total()); ?> User TDS Data </h4>
                            </div>
                            <div class="content-header-right col-md-6 col-12">
                                
                                
                            </div>
                        </div>

                        <div class="col-12">
                            <table class="table table-striped table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th>Token Number</th>
                                        <th>Receipt Date</th>
                                        <th>Bar Code Value</th>
                                        <th>Deductor/Collector Name</th>
                                        <th>Financial Year</th>
                                        <th>Quarter</th>
                                        <th>Form No.</th>
                                        <th>TAN</th>
                                        <th>Regular Correction</th>
                                        <th>Original Token No.</th>
                                        <th>Fees Charged</th>
                                        <th>Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $tds_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($data['token_number']); ?></td>
                                        <td><?php echo e($data['receipt_date']); ?></td>
                                        <td><?php echo e($data['barcode_value']); ?></td>
                                        <td><?php echo e($data['deductor_collector_name']); ?></td>
                                        <td><?php echo e($data['financial_year']); ?></td>
                                        <td><?php echo e($data['quarter']); ?></td>
                                        <td><?php echo e($data['form_no']); ?></td>
                                        <td><?php echo e($data['tan']); ?></td>
                                        <td><?php echo e($data['regular_correction']); ?></td>
                                        <td><?php echo e($data['original_token_no']); ?></td>
                                        <td><?php echo e($data['fees_charged']); ?></td>
                                        <td class="table-action">
                                            <a href="<?php echo e(url('/admin/upload-documents/tds-data/'.$data['id'])); ?>" class="action-icon"><i
                                                class="mdi mdi-pencil"></i></a>
                                                <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/delete-tds-data/'.$data['id'])); ?>" class="action-icon"> <i
                                                    class="mdi mdi-delete"></i></a>
                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="text-center">
                                        <th colspan="5">
                                            No records found
                                        </th>
                                    </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            <?php echo e($tds_data->links()); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $("#tax_type").on('change', function(){
            $('.excel').show();
        });
        // $("#userform").submit(function(){
        //     if($("#tax_type").val()==null){
        //         alert("null");
        //     }else{
        //         alert("value");
        //     }
        // })
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/admin/edit-user.blade.php ENDPATH**/ ?>