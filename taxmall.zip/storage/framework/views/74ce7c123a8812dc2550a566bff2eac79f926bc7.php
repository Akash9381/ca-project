<?php $__env->startSection('title', 'Tax Mail - Edit GST'); ?>
<style>
    * {
      box-sizing: border-box;
    }

    .zoom {
      /* padding: 50px; */
      background-color: green;
      transition: transform .2s;
      width: 40px;
      height: 40px;
      margin: 0 auto;
    }

    .zoom:hover {
      -ms-transform: scale(1.5); /* IE 9 */
      -webkit-transform: scale(1.5); /* Safari 3-8 */
      transform: scale(10);
      margin-bottom: 40px;
    }
    </style>
<?php $__env->startSection('content'); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="content-header row pt-3">
                        <div class="content-header-left col-md-6 col-12">
                            <h4 class="card-title">Update GST Data </h4>
                        </div>
                        <div class="content-header-right col-md-6 col-12">
                            <div class="btn-group" style="float: right!important;" role="group"
                                aria-label="Button group with nested dropdown">
                                <div class="btn-group mb-1" role="group">
                                    <a href="<?php echo e(url('/admin/users')); ?>"
                                        class="btn btn-outline-primary dropdown-menu-right"><i
                                            class="feather uil-arrow-left icon-left"></i>Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <form method="POST" id="userform" action="<?php echo e(url('admin/update-documents/gst-data/'.$gstdata['id'])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">ARN</label>
                            <input type="text" class="form-control" style="text-transform: capitalize" value="<?php echo e($gstdata['arn']); ?>" name="arn"  placeholder="Enter ARN">
                            <?php $__errorArgs = ['arn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="name-error" class="error" for="name"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label class="form-label">Return Type</label>
                            <select class="form-control" name="return_type" id="return_type">
                                <option selected disabled style="display:none;">Select GST Type</option>
                                <option <?php if($gstdata['return_type']=='GSTR3B'): ?>
                                    selected
                                <?php endif; ?> value="GSTR3B">GSTR3B</option>
                                <option  <?php if($gstdata['return_type']=='GSTR-1/IFF'): ?>
                                selected
                            <?php endif; ?> value="GSTR-1/IFF">GSTR-1/IFF</option>
                            </select>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Financial Year</label>
                            <input type="text" class="form-control" name="financial_year" value="<?php echo e($gstdata['financial_year']); ?>"  placeholder="Enter Financial Year">
                            <?php $__errorArgs = ['financial_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="email-error" class="error" for="email"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Tax Period</label>
                            <select class="form-control" name="tax_period" id="tax_period">
                                <option selected style="display:none;">Months</option>
                                <option <?php if($gstdata['tax_period']=='January'): ?>
                                selected
                                <?php endif; ?> value="January">January</option>
                                <option <?php if($gstdata['tax_period']=='February'): ?>
                                selected
                                <?php endif; ?> value="February">February</option>
                                <option <?php if($gstdata['tax_period']=='March'): ?>
                                selected
                                <?php endif; ?> value="March">March</option>
                                <option <?php if($gstdata['tax_period']=='April'): ?>
                                selected
                                <?php endif; ?> value="April">April</option>
                                <option <?php if($gstdata['tax_period']=='May'): ?>
                                selected
                                <?php endif; ?> value="May">May</option>
                                <option <?php if($gstdata['tax_period']=='June'): ?>
                                selected
                                <?php endif; ?> value="June">June</option>
                                <option <?php if($gstdata['tax_period']=='July'): ?>
                                selected
                                <?php endif; ?> value="July">July</option>
                                <option <?php if($gstdata['tax_period']=='August'): ?>
                                selected
                                <?php endif; ?> value="August">August</option>
                                <option <?php if($gstdata['tax_period']=='September'): ?>
                                selected
                                <?php endif; ?> value="September">September</option>
                                <option <?php if($gstdata['tax_period']=='October'): ?>
                                selected
                                <?php endif; ?> value="October">October</option>
                                <option <?php if($gstdata['tax_period']=='November'): ?>
                                selected
                                <?php endif; ?> value="November">November</option>
                                <option <?php if($gstdata['tax_period']=='December'): ?>
                                selected
                                <?php endif; ?> value="December">December</option>
                            </select>
                            <?php $__errorArgs = ['tax_period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="tax_period-error" class="error" for="tax_period"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Filing Date</label>
                            <input type="date" class="form-control" value="<?php echo e($gstdata['filing_date']); ?>" name="filing_date">
                            <?php $__errorArgs = ['filing_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="filing_date-error" class="error" for="filing_date"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Status</label>
                            <select class="form-control" name="status" id="status1">
                                <option selected style="display:none;">Status</option>
                                <option <?php if($gstdata['status']=='Filed'): ?>
                                    selected
                                <?php endif; ?> value="Filed">Filed</option>
                                <option <?php if($gstdata['status']=='Not-Field'): ?>
                                selected
                            <?php endif; ?> value="Not-Field">Not-Field</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="status-error" class="error" for="status"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Mode Of Filing</label>
                            <select class="form-control" name="mode_of_filing" id="mode_of_filing">
                                <option selected disabled>Mode Of Filing</option>
                                <option <?php if($gstdata['mode_of_filing']=='ONLINE'): ?>
                                selected
                            <?php endif; ?> value="ONLINE">ONLINE</option>
                                <option <?php if($gstdata['mode_of_filing']=='OFFLINE'): ?>
                                selected
                            <?php endif; ?> value="OFFLINE">OFFLINE</option>
                            </select>
                            <?php $__errorArgs = ['mode_of_filing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="mode_of_filing-error" class="error" for="mode_of_filing"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Type</label>
                            <select class="form-control" name="type" id="type">
                                <option selected disabled>Select Type</option>
                                <option value="Achnowledgement" >Achnowledgement</option>
                                <option value="Form" >Form</option>
                                <option value="Challan">Challan</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="type-error" class="error" for="type"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label class="form-label">Upload Documents</label>
                            <input class="form-control" id="documents" accept=".png, .jpg, .jpeg, .pdf, .docx, .doc" name="documents[]" multiple type="file" >
                        </div>
                    </div>
                    <div class="row">
                        <?php if(isset($gstdocuments)): ?>
                        <label class="form-label"><strong>Uploded Documents </strong></label><br>
                        <label class="form-label">Achnowledgement Documents</label>
                        <?php $__currentLoopData = $gstdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Achnowledgement'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/gst-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/GST/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Form Documents</label>
                        <?php $__currentLoopData = $gstdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Form'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/gst-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/GST/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Challan Documents</label>
                        <?php $__currentLoopData = $gstdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Challan'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/gst-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/GST/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $("#tax_type").on('change', function(){
        $('.excel').show();
    });
    // $("#userform").submit(function(){
    //     if($("#tax_type").val()==null){
    //         alert("null");
    //     }else{
    //         alert("value");
    //     }
    // })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/admin/gst.blade.php ENDPATH**/ ?>