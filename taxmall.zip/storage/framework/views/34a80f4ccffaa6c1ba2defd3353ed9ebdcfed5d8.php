<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <link href="<?php echo e(asset('login/dashboard/demo.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('login/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js" integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <style>
        *{
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
                    /* Chrome, Safari, Edge, Opera */
            input::-webkit-outer-spin-button,
            input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
            }

            /* Firefox */
            input[type=number] {
            -moz-appearance: textfield;
            }
            .error{
                color: red;
            }
    </style>
</head>
<body>
    <header class="text-center">
        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('login/img/tall img.jpg')); ?>" alt="logo"><h1 style="color: #212529">TAX MALL</h1></a>
    </header>
    <fieldset>
    <form id="otpform" class="text-center shadow rounded mt-5" action="<?php echo e(url('otpverify')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h2> Enter Your Registered Mobile Number</h2>
        <?php if(session()->has('otperror')): ?>
        <div class="alert alert-danger">
        <?php echo e(session()->get('otperror')); ?>

        </div>
        <?php endif; ?>
        <p class="alert alert-danger anauthorized" style="display: none">Unauthorized Person! Please contact to admin.</p>
        <p class="alert alert-success success" style="display: none">Please Input Your OTP</p>
        <p class="alert alert-danger error" style="display: none">Enter Valid Number!</p>
            <div class="m-3 text-center">
            <input type="number" class="justify-content-center w-100" value="<?php echo e(old('number')); ?>" placeholder="Mobile Number" class="form-control" id="number" name="number">
            <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <label id="number-error" class="error" for="number"><?php echo e($message); ?></label>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="m-3 text-center fs-3">
                <input type="number" class="justify-content-center w-100" name="otp" minlength='4'
                maxlength='4' placeholder="Enter OTP" class="form-control" >
                <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label id="otp-error" class="error" for="otp"><?php echo e($message); ?></label>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        <div class="m-3" class="fbut">
            <a type="button" id="optgenerate"  class="btn btn-success w-100" style="color: white">GET OTP</a>
        </div>
        <div class="m-3" class="fbut">
            <a href="dashboard.html">
        <button type="submit" class="btn btn-success w-100">LOG IN</button></a>
        </div>
    </form>
    </fieldset>

    <script>
        $(document).ready(function(){
            $("#otpform").validate({
                rules:{
                    number:{
                        required:true,
                        minlength:10,
                        maxlength:10
                    },
                    otp:{
                        required:true,
                        minlength:4,
                        maxlength:4
                    }
                }
            })

            $("#optgenerate").click(function(){
                let number = $("#number").val();
                $.ajax({
                    url:'/otp-generate/',
                    method:'POST',
                    data:{number:number,_token:"<?php echo e(csrf_token()); ?>"},
                    success:function(res){
                        if(res.success == true){
                            $(".anauthorized").hide();
                            $(".success").show();
                            $(".error").hide();
                        }else if(res.error){
                            $(".anauthorized").hide();
                            $(".success").hide();
                            $(".error").show();
                        }else{
                            $(".anauthorized").show();
                            $(".success").hide();
                            $(".error").hide();
                        }
                    }
            })
            })
        });
    </script>
</body>
</html>
<?php /**PATH G:\Akash\git project\tax-mail\resources\views/frontend/login/login.blade.php ENDPATH**/ ?>