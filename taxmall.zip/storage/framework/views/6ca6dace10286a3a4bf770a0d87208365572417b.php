<?php $__env->startSection('title', 'Tax Mail - Edit TDS'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="content-header row pt-3">
                        <div class="content-header-left col-md-6 col-12">
                            <h4 class="card-title">Edit TDS Data </h4>
                        </div>
                        <div class="content-header-right col-md-6 col-12">
                            <div class="btn-group" style="float: right!important;" role="group"
                                aria-label="Button group with nested dropdown">
                                <div class="btn-group mb-1" role="group">
                                    <a href="<?php echo e(url('/admin/users')); ?>"
                                        class="btn btn-outline-primary dropdown-menu-right"><i
                                            class="feather uil-arrow-left icon-left"></i>Back</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <form method="POST" id="userform" action="<?php echo e(url('admin/update-documents/tds-data/'.$tdsdata['id'])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Token No.</label>
                            <input type="number" class="form-control"  value="<?php echo e($tdsdata['token_number']); ?>" name="token_number"  placeholder="Enter Token No.">
                            <?php $__errorArgs = ['token_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label id="token_number-error" class="error" for="token_number"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label class="form-label">Receipt Date</label>
                            <input type="date" class="form-control" value="<?php echo e($tdsdata['receipt_date']); ?>" name="receipt_date">
                            <?php $__errorArgs = ['receipt_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="receipt_date-error" class="error" for="receipt_date"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">BarCode Value</label>
                            <input type="text" class="form-control" name="barcode_value" value="<?php echo e($tdsdata['barcode_value']); ?>"  placeholder="Enter Financial Year">
                            <?php $__errorArgs = ['barcode_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label id="barcode_value-error" class="error" for="barcode_value"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Deductor/Collector Name</label>
                            <input type="text" class="form-control" style="text-transform: capitalize" name="deductor_collector_name" value="<?php echo e($tdsdata['deductor_collector_name']); ?>"  placeholder="Enter Deductor/Collector Name">

                            <?php $__errorArgs = ['deductor_collector_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="deductor_collector_name-error" class="error" for="deductor_collector_name"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Financial Year</label>
                            <input type="text" class="form-control" value="<?php echo e($tdsdata['financial_year']); ?>" name="financial_year">
                            <?php $__errorArgs = ['financial_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="financial_year-error" class="error" for="financial_year"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Quarter</label>
                            <select class="form-control" name="quarter" id="quarter">
                                <option selected style="display:none;">Select Quarter</option>
                                <option <?php if($tdsdata['quarter']=='Q1'): ?>
                                    selected
                                <?php endif; ?> value="Q1">Q1</option>
                                <option <?php if($tdsdata['quarter']=='Q2'): ?>
                                selected
                            <?php endif; ?> value="Q2">Q2</option>
                                <option <?php if($tdsdata['quarter']=='Q3'): ?>
                                selected
                            <?php endif; ?> value="Q3">Q3</option>
                                <option <?php if($tdsdata['quarter']=='Q4'): ?>
                                selected
                            <?php endif; ?> value="Q4">Q4</option>
                            </select>
                            <?php $__errorArgs = ['quarter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="quarter-error" class="error" for="quarter"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Form No.</label>
                            <input class="form-control" id="form_no" name="form_no" value="<?php echo e($tdsdata['form_no']); ?>" type="text" >
                            <?php $__errorArgs = ['form_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="form_no-error" class="error" for="form_no"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">TAN</label>
                            <input class="form-control" id="tan" name="tan" value="<?php echo e($tdsdata['tan']); ?>" type="text" >
                            <?php $__errorArgs = ['tan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="tan-error" class="error" for="tan"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Regular/Correction</label>
                            <select class="form-control" name="regular_correction" id="regular_correction">
                                <option selected style="display:none;">Select</option>
                                <option <?php if($tdsdata['regular_correction']=='Regular'): ?>
                                selected
                                <?php endif; ?> value="Regular">Regular</option>
                                <option <?php if($tdsdata['regular_correction']=='Correction'): ?>
                                selected
                                <?php endif; ?> value="Correction">Correction</option>
                            </select>
                            <?php $__errorArgs = ['regular_correction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label id="regular_correction-error" class="error" for="regular_correction"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Original Token No.</label>
                            <input class="form-control" id="original_token_no" name="original_token_no" value="<?php echo e($tdsdata['original_token_no']); ?>" type="text" >
                            <?php $__errorArgs = ['original_token_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="original_token_no-error" class="error" for="original_token_no"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Fees Charged</label>
                            <input class="form-control" id="fees_charged" name="fees_charged" value="<?php echo e($tdsdata['fees_charged']); ?>" type="text" >
                            <?php $__errorArgs = ['fees_charged'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="fees_charged-error" class="error" for="fees_charged"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label  class="form-label">Type</label>
                            <select class="form-control" name="type" id="type">
                                <option selected disabled>Select Type</option>
                                <option value="Achnowledgement">Achnowledgement</option>
                                <option value="Form">Form</option>
                                <option value="Challan">Challan</option>
                                <option value="Challan Status Enquiry">Challan Status Enquiry</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label id="type-error" class="error" for="type"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-md-6">
                            <label class="form-label">Upload Documents</label>
                            <input class="form-control" id="documents" accept=".png, .jpg, .jpeg, .pdf, .docx, .doc" name="documents[]" multiple type="file" >
                        </div>
                    </div>
                    <div class="row">
                        <?php if(isset($tdsdatadocuments)): ?>
                        <label class="form-label"><strong>Uploded Documents </strong></label><br>
                        <label class="form-label">Achnowledgement Documents</label>
                        <?php $__currentLoopData = $tdsdatadocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Achnowledgement'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/tds-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Form Documents</label>
                        <?php $__currentLoopData = $tdsdatadocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Form'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/tds-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Challan Documents</label>
                        <?php $__currentLoopData = $tdsdatadocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Challan'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/tds-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-label">Challan Status Enquiry Documents</label>
                        <?php $__currentLoopData = $tdsdatadocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['type']=='Challan Status Enquiry'): ?>
                        <div class="mb-3 col-md-6 col-12 text-center">
                            <a onclick="return confirm('Are You Sure to Delete?')" href="<?php echo e(url('admin/tds-document-delete/'.$item['id'])); ?>"><i class="mdi mdi-delete"></i></a><br>
                            <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $("#tax_type").on('change', function(){
        $('.excel').show();
    });
    // $("#userform").submit(function(){
    //     if($("#tax_type").val()==null){
    //         alert("null");
    //     }else{
    //         alert("value");
    //     }
    // })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/admin/tds.blade.php ENDPATH**/ ?>