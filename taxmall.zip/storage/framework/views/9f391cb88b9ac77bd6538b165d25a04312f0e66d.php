<!-- ========== Left Sidebar Start ========== -->
<div class="leftside-menu">

    <!-- Logo Light -->
    <a href="<?php echo e(url('/admin/dashboard')); ?>"  class="logo logo-light">
        <span class="logo-lg">
            <img style="background-color: white" class="img-fluid" src="<?php echo e(asset('frontend/assets/img/tax-mall.png')); ?>" alt="logo" height="22">
        </span>
        <span class="logo-sm">
            <img class="img-fluid" src="<?php echo e(asset('login/img/tall img.jpg')); ?>" alt="small logo" height="22">
        </span>
    </a>

    <!-- Logo Dark -->
    <a href="<?php echo e(url('/admin/dashboard')); ?>" class="logo logo-dark">
        <span class="logo-lg">
            <img src="<?php echo e(url('/admin/assets/images/logo-dark.png')); ?>" alt="dark logo" height="22">
        </span>
        <span class="logo-sm">
            <img src="<?php echo e(url('/admin/assets/images/logo-dark-sm.png')); ?>" alt="small logo" height="22">
        </span>
    </a>

    <!-- Sidebar Hover Menu Toggle Button -->
    <button type="button" class="btn button-sm-hover p-0" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
        <i class="ri-checkbox-blank-circle-line align-middle"></i>
    </button>

    <!-- Sidebar -left -->
    <div class="h-100" id="leftside-menu-container" data-simplebar>
        <!-- Leftbar User -->
        <div class="leftbar-user">
            <a href="pages-profile.html">
                <img src="<?php echo e(url('/admin/assets/images/users/avatar-1.jpg')); ?>" alt="user-image" height="42"
                    class="rounded-circle shadow-sm">
                <span class="leftbar-user-name">Dominic Keller</span>
            </a>
        </div>

        <!--- Sidemenu -->
        <ul class="side-nav">

            <li class="side-nav-title side-nav-item">Navigation</li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="<?php echo e(url('/admin/dashboard')); ?>"
                     class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Dashboards </span>
                </a>
            </li>

            <li class="side-nav-title side-nav-item">Apps</li>

            <li class="side-nav-item">
                <a href="<?php echo e(url('/admin/users')); ?>" class="side-nav-link">
                    <i class="uil-user"></i>
                    <span> Users </span>
                </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(url('/admin/create-user')); ?>" class="side-nav-link">
                    <i class="uil-plus-circle"></i>
                    <span>Create User</span>
                </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(url('/admin/upload-documents')); ?>" class="side-nav-link">
                    <i class="uil-upload"></i>
                    <span>Upload Document</span>
                </a>
            </li>

        </ul>
        <!--- End Sidemenu -->



        <div class="clearfix"></div>
    </div>
</div>
<!-- ========== Left Sidebar End ========== -->
<?php /**PATH G:\Akash\git project\tax-mail\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>