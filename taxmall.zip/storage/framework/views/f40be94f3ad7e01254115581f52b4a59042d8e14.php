<?php $__env->startSection('content'); ?>
    <div class="main-panel" id="main-panel">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
            <div class="row text-light">
                <div class="col-12 mt-1">
                    Deductor/Collector Name: <b><?php echo e($tdsdata['deductor_collector_name']); ?></b>
                </div>
                <div class="col-md-6">
                    Token Number: <b><?php echo e($tdsdata['token_number']); ?></b>
                </div>
                <div class="col-md-6 mt-1">
                    Receipt Date: <b><?php echo e($tdsdata['receipt_date']); ?></b>
                </div>
                <div class="col-md-6 mt-1">
                    Bar Code Value: <b><?php echo e($tdsdata['barcode_value']); ?></b>
                </div>
                <div class="col-md-6 mt-1">
                    Financial Year: <b><?php echo e($tdsdata['financial_year']); ?></b>
                </div>
                <div class="col-md-6 mt-1">
                    Quarter: <b><?php echo e($tdsdata['quarter']); ?></b>
                </div>
                <div class="col-md-6 my-1">
                    Form No.: <b><?php echo e($tdsdata['form_no']); ?></b>
                </div>
                <div class="col-md-6 my-1">
                    TAN: <b><?php echo e($tdsdata['tan']); ?></b>
                </div>
                <div class="col-md-6 my-1">
                    Regular Correction: <b><?php echo e($tdsdata['regular_correction']); ?></b>
                </div>
                <div class="col-md-6 my-1">
                    Original Token No.: <b><?php echo e($tdsdata['original_token_no']); ?></b>
                </div>
                <div class="col-md-6 my-1">
                    Fees Charged: <b><?php echo e($tdsdata['fees_charged']); ?></b>
                </div>
            </div>
            <div class="container-fluid">
                <div class="navbar-wrapper">
                    <div class="navbar-toggle">
                        <button type="button" class="navbar-toggler">
                            <span class="navbar-toggler-bar bar1"></span>
                            <span class="navbar-toggler-bar bar2"></span>
                            <span class="navbar-toggler-bar bar3"></span>
                        </button>
                    </div>
                    

                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                    aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                    <span class="navbar-toggler-bar navbar-kebab"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navigation">

                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <p>
                                <span class="d-lg-none d-md-block">Status</span>
                            </p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="panel-header panel-header-lg">

            
        </div>
        <div class="content">

        <?php if(isset($tdsdocuments)): ?>
        <div class="row mt-5">
            <div class="col-12">
                <h3 for=""><u>Achnowledgement</u></h3>
            </div>
        </div>
        <?php $__currentLoopData = $tdsdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row"  >
                <?php if($item['type']=='Achnowledgement'): ?>
                <div class="mb-3 col-md-6 col-12">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="row">
            <div class="col-12">
                <h3 for=""><u>Form</u></h3>
            </div>
        </div>
        <?php $__currentLoopData = $tdsdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row"  >
                <?php if($item['type']=='Form'): ?>
                <div class="mb-3 col-md-6 col-12">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="row">
            <div class="col-12">
                <h3 for=""><u>Challan</u></h3>
            </div>
        </div>
        <?php $__currentLoopData = $tdsdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row"  >
                <?php if($item['type']=='Challam'): ?>
                <div class="mb-3 col-md-6 col-12">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="row">
            <div class="col-12">
                <h3 for=""><u>Challan Status Enquiry</u></h3>
            </div>
        </div>
        <?php $__currentLoopData = $tdsdocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row"  >
                <?php if($item['type']=='Challan Status Enquiry'): ?>
                <div class="mb-3 col-md-6 col-12 ">
                    <iframe width="50%" class="mb-3" height="300" src="<?php echo e(asset('Library/TDS/'.$item['documents'])); ?>" ></iframe><br>
                </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.dashboard_layouts.dashboard_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Akash\git project\tax-mail\resources\views/frontend/login/tdsdata.blade.php ENDPATH**/ ?>